import { handlers } from "../../../../auth" // Перевір, щоб шлях вів до твого файлу auth.ts
export const { GET, POST } = handlers
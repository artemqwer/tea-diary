/** @type {import('next').NextConfig} */
const nextConfig = {
    // Тут поки що пусто, і це ок
};

export default nextConfig;